<?php
session_start();

$servername = "rdbms.strato.de";
$username = "dbu3645296";
$password = "Imad12345@";
$dbname = "dbs12312128";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected";
} catch(PDOException $e) {
    echo "Databaseverbinding mislukt: " . $e->getMessage();
}



// Dit is voor de admin pagina 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $admin_username = "imad";
    $admin_password = "0000";

    $input_username = $_POST["username"];
    $input_password = $_POST["password"];

    if ($input_username == $admin_username && $input_password == $admin_password) {
        $_SESSION["loggedin"] = true;
        header("Location: kies.php");
        exit;
    } else {
        $error = "FOUT! je bent geen admin";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login voor admin</title>
</head>
<body>
    <h2>Admin Login</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <input type="text" name="username" placeholder="Gebruikersnaam"><br><br>
        <input type="password" name="password" placeholder="Wachtwoord"><br><br>
        <input type="submit" value="Login">
    </form>
    <?php if(isset($error)) echo $error; ?>
	
	 <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            width: 80%;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
        }
        form {
            text-align: center;
            margin-bottom: 20px;
        }
        label {
            font-weight: bold;
        }
        input[type="text"], input[type="submit"] {
            padding: 8px;
            margin: 6px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            cursor: pointer;
        }
		
		    input[type="password"], input[type="password"] {
            padding: 8px;
            margin: 6px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #007bff;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</body>

</html>

