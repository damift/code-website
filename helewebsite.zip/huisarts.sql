-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 24 nov 2023 om 12:06
-- Serverversie: 10.4.28-MariaDB
-- PHP-versie: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `huisarts`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `mock_data`
--

CREATE TABLE `mock_data` (
  `Patient_id` int(11) DEFAULT NULL,
  `Voornaam` varchar(50) DEFAULT NULL,
  `Achternaam` varchar(50) DEFAULT NULL,
  `adres` varchar(50) DEFAULT NULL,
  `plaats` varchar(50) DEFAULT NULL,
  `telefoonnummer` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `mock_data`
--

INSERT INTO `mock_data` (`Patient_id`, `Voornaam`, `Achternaam`, `adres`, `plaats`, `telefoonnummer`) VALUES
(5, 'Alister', 'Reffe', '3086 Northland Hill', 'Yelenendorf', '+994 939 173 1494'),
(6, 'Freida', 'Blethin', '79 Di Loreto Lane', 'Duotian', '+86 757 449 3426'),
(7, 'Meriel', 'Morrissey', '93 Manufacturers Pass', 'Xinxi', '+86 530 292 5493'),
(8, 'Ruddy', 'Circuitt', '308 Fair Oaks Center', 'Gangshangji', '+86 766 831 7518'),
(9, 'Rowe', 'Yannoni', '966 Pepper Wood Plaza', 'Vila Alva', '+351 868 299 1459'),
(10, 'Tisha', 'Sparrowe', '875 Thierer Way', 'Made', '+62 143 390 5111'),
(11, 'Vin', 'Pie', '74552 Elmside Street', 'San Juan de la Maguana', '+1 734 662 3209'),
(12, 'Allene', 'Guinnane', '59 Lakeland Lane', 'Oja', '+62 293 668 6077'),
(13, 'Bella', 'Shales', '1162 Sheridan Place', 'Yataity del Norte', '+595 191 332 7327'),
(14, 'Alfreda', 'Ribbon', '41 Nancy Pass', 'Lukou', '+86 319 867 4282'),
(15, 'Darrick', 'Shillington', '46 Manufacturers Junction', 'Luleå', '+46 601 950 1656'),
(16, 'Yolanda', 'Gomes', '79358 Manley Junction', 'Kolaka', '+62 154 941 5153'),
(17, 'Gerrard', 'Mattam', '6981 Eastwood Lane', 'Shipunovo', '+7 974 386 9628'),
(18, 'Ted', 'Sammes', '570 Montana Trail', 'Almaguer', '+57 805 931 8491'),
(19, 'Chauncey', 'Bale', '15187 Prairie Rose Junction', 'Watuka', '+62 771 214 4543'),
(20, 'Welby', 'Petroff', '2154 Lotheville Junction', 'Tadou', '+86 806 139 6507'),
(21, 'Curry', 'Newlands', '3 Lyons Alley', 'Yu’erhong', '+86 847 835 5797'),
(22, 'Georgena', 'Skittreal', '14157 Hansons Circle', 'Lubbock', '+1 806 353 1865'),
(23, 'Lennie', 'Lucus', '09351 Warrior Way', 'Poroçan', '+355 920 482 2883'),
(24, 'Rodge', 'Kelsey', '2496 Mayer Circle', 'Pinggang', '+86 226 831 0163'),
(25, 'Genevieve', 'Huleatt', '839 High Crossing Point', 'Kasui', '+62 617 842 5588'),
(26, 'Jaye', 'Marryatt', '6 Lindbergh Road', 'Tateyama', '+81 884 637 2711'),
(27, 'Ramon', 'Fladgate', '286 Cherokee Road', 'Remscheid', '+49 349 750 9508'),
(28, 'Jareb', 'Grotty', '40089 Express Crossing', 'Khadyzhensk', '+7 249 679 3069'),
(29, 'Demetre', 'Siegertsz', '97 Grim Plaza', 'Klumbu', '+62 544 544 7782'),
(30, 'Amii', 'Frogley', '202 Johnson Trail', 'Beringovskiy', '+7 404 581 9115'),
(31, 'Herminia', 'Culter', '7893 Bartillon Hill', 'Nancha', '+86 793 161 8607'),
(32, 'Alina', 'Dennehy', '7 Manufacturers Alley', 'Tilcara', '+54 180 746 7939'),
(33, 'Corena', 'Reedie', '86089 Dunning Center', 'Walnut Grove', '+1 245 897 8705'),
(34, 'Angele', 'Boothman', '4658 Center Street', 'Concordia', '+51 432 826 4060'),
(35, 'Dulcy', 'Guymer', '24 Orin Point', 'Liyang', '+86 647 946 4824'),
(36, 'Raf', 'Storrier', '91352 Knutson Drive', 'Siderejo', '+62 869 940 9642'),
(37, 'Lidia', 'Johanssen', '274 Cottonwood Road', 'Bandhagen', '+46 847 581 4505'),
(38, 'Clarissa', 'Winchurst', '70 Lake View Drive', 'Druzhny', '+375 611 540 3036'),
(39, 'Raymund', 'Luno', '43345 International Park', 'Jatinagara Kulon', '+62 289 944 0858'),
(40, 'Elna', 'Tidcomb', '03741 Evergreen Park', 'Moutfort', '+352 553 105 9719'),
(41, 'Royce', 'Withrington', '37 Longview Plaza', 'Ábidos', '+55 841 338 5238'),
(42, 'Madison', 'Whartonby', '771 Mcguire Circle', 'Vila Nova Sintra', '+238 374 325 8424'),
(43, 'Bartholomew', 'Taborre', '0 Kensington Plaza', 'Sandy Bay', '+1 737 651 6986'),
(44, 'Josi', 'Bon', '9 Toban Center', 'Ādaži', '+371 234 390 1536'),
(45, 'Rosalinde', 'Michele', '9 Mosinee Avenue', 'Kulevcha', '+380 519 369 8286'),
(46, 'Hulda', 'Lillee', '03 Boyd Parkway', 'Gabao', '+63 453 884 1926'),
(47, 'Hortensia', 'Morit', '9 Killdeer Crossing', 'Kapinango', '+62 913 854 1419'),
(48, 'Gavan', 'Pregel', '015 Nevada Place', 'Almirante Tamandaré', '+55 488 331 2685'),
(49, 'Harmonia', 'Gopsell', '99 Mccormick Way', 'Cinyawang', '+62 301 705 7192'),
(50, 'Jenelle', 'Ancketill', '7 Maple Point', 'Bulihan', '+63 647 142 3478'),
(51, 'Jodie', 'Krout', '0006 Forster Crossing', 'Rybinsk', '+7 101 685 1333'),
(52, 'Munmro', 'Illyes', '23 Fremont Street', 'Kushnarënkovo', '+7 332 694 8086'),
(53, 'Virginia', 'Dundendale', '55 Milwaukee Way', 'Rustam jo Goth', '+92 548 867 6405'),
(54, 'Arnuad', 'Filintsev', '96590 Buhler Hill', 'Karlstad', '+46 764 585 6007'),
(55, 'Shalom', 'Dranfield', '9 Debra Center', 'Gaoliang', '+86 481 947 4794'),
(56, 'Darsey', 'de Glanville', '114 Artisan Point', 'Oslo', '+47 419 417 0486'),
(57, 'Maggy', 'Aguirre', '9885 Oakridge Terrace', 'El Benque', '+504 990 400 0633'),
(58, 'Beilul', 'Sharrem', '32101 Messerschmidt Crossing', 'Sumberbening', '+62 707 508 5109'),
(59, 'Bella', 'Daysh', '26 Shelley Hill', 'Arbaoua', '+212 455 752 9391'),
(60, 'Tanhya', 'MacMakin', '6100 Fordem Parkway', 'Shichuan', '+86 387 815 5531'),
(61, 'Dori', 'Giblin', '0 Carpenter Center', 'Grästorp', '+46 988 361 1935'),
(62, 'Raquel', 'Trusty', '1267 Novick Terrace', 'Santa Rosa', '+52 125 659 8055'),
(63, 'Cariotta', 'Mountstephen', '783 Village Pass', 'Yinyang', '+86 780 884 3651'),
(64, 'Nikolia', 'Jekel', '18 Kensington Terrace', 'Melikkrajan', '+62 670 609 4294'),
(65, 'Gregoor', 'Massinger', '4750 Crescent Oaks Circle', 'Słotowa', '+48 935 570 5414'),
(66, 'Stern', 'Ritzman', '810 Green Ridge Road', 'Wangqingtuo', '+86 924 481 1060'),
(67, 'Cherlyn', 'Godlonton', '8552 Cottonwood Road', 'Hongyi', '+86 393 339 5707'),
(68, 'Anneliese', 'Proudman', '93 Monterey Lane', 'Palca', '+51 281 779 1009'),
(69, 'Cicely', 'Denisyev', '732 Haas Terrace', 'Tongqian', '+86 365 142 0234'),
(70, 'Patty', 'Winwood', '04933 Coleman Trail', 'Conchal', '+55 885 671 7398'),
(71, 'Alysa', 'Medhurst', '4676 Hansons Way', 'Kasreman Wetan', '+62 609 348 6260'),
(72, 'Gabbi', 'Swayne', '5 Clarendon Parkway', 'Martanesh', '+355 217 496 4957'),
(73, 'Jacobo', 'Poston', '3 Lawn Pass', 'Nakovo', '+381 942 779 9101'),
(74, 'Elsy', 'Whitnall', '35269 Rigney Place', 'Bayramaly', '+993 845 180 4655'),
(75, 'Betta', 'Galey', '8003 Crescent Oaks Avenue', 'Fundación', '+1 236 409 6491'),
(76, 'Deana', 'Gossop', '6 Coolidge Crossing', 'Kurayyimah', '+962 579 589 4716'),
(77, 'Bern', 'Tender', '9 Truax Street', 'Deqing', '+86 724 602 9820'),
(78, 'Desmond', 'Powder', '600 Pierstorff Point', 'Gorzów Śląski', '+48 945 711 5968'),
(79, 'Rudolf', 'Stather', '286 Duke Lane', 'Fujioka', '+81 433 284 8242'),
(80, 'Eddie', 'Calladine', '8 Dahle Place', 'Dakoro', '+227 655 362 5029'),
(NULL, '', '', '', '', ''),
(NULL, 'imad', 'ftatchi', 'jachtlaan 28', 'ede', '0614562890'),
(NULL, 'imad', 'ftatchi', 'jachtlaan 28', 'ede', '0614562890'),
(NULL, 'imad', 'ftatchi', 'jachtlaan 28', 'ede', '0614562890'),
(NULL, 'imad', 'reffe', 'jachtlaan 28', 'ede', '0614562890');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `patient_notes`
--

CREATE TABLE `patient_notes` (
  `note_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `note_content` text NOT NULL,
  `note_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `patient_notes`
--

INSERT INTO `patient_notes` (`note_id`, `patient_id`, `note_content`, `note_date`) VALUES
(1, 0, 'cwdqd', '2023-11-21 13:00:12'),
(2, 0, 'ja', '2023-11-22 08:46:45'),
(3, 0, 'imad', '2023-11-22 12:35:09'),
(4, 0, 'imad', '2023-11-22 12:35:47');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `patient_notes`
--
ALTER TABLE `patient_notes`
  ADD PRIMARY KEY (`note_id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `patient_notes`
--
ALTER TABLE `patient_notes`
  MODIFY `note_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
